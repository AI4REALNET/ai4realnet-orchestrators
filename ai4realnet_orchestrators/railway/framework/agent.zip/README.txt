maze-flatland behavioural-cloning reference agent for the railway
robustness/resilience KPIs (KPI-DF-069 .. KPI-RF-078).

Contents
  state_dict-epoch_200.pt  trained policy weights
  spaces_config.pkl        observation/action space config saved with the run
  training_config.yaml     the run hydra config; build_maze_env() reproduces it
  LICENSE.maze-flatland    MIT licence of maze-flatland (c) 2025 EnliteAI GmbH

Loaded by test_runner_robustness_resilience_kpi_069_077._load_agent_from_zip(),
which detects state_dict-*.pt + spaces_config.pkl and wraps the policy in a
MazeFlatlandDefender.
